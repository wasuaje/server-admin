<?php
/**
 * Redirect to the status.php page
 *
 * @author Sam
 */

require "inc.php";

redirect("status.php");
?>
