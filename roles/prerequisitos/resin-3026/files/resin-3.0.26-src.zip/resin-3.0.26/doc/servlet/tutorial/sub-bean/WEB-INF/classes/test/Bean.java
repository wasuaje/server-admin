package test;

public class Bean {
  private String _value;

  public void setValue(String value)
  {
    _value = value;
  }

  public String getValue()
  {
    return _value;
  }
}
