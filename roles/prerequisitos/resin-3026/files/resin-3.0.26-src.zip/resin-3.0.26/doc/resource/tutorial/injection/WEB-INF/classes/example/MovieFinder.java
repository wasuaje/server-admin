package example;

import java.util.List;

public interface MovieFinder {
  /**
   * Returns all the movies.
   */
  public List findAll();
}
