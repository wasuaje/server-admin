package example.entity.home;

import java.rmi.*;
import javax.ejb.*;

/**
 * The object interface is just a dummy.
 */
public interface HomeObj extends EJBObject {
}
