package example.cmp.transaction;

/**
 *
 */
public class RegistrationDeniedException extends Exception {

  public RegistrationDeniedException(String msg) {
    super(msg);
  }

}
