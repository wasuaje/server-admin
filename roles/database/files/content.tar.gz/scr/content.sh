#!/bin/sh

OLD_UMASK=`umask`
umask 0027
mkdir -p /mnt/data/basesdedatos/content/control_files
mkdir -p /mnt/data/basesdedatos/content/redo_logs
mkdir -p /mnt/data/fast_recovery_area
mkdir -p /mnt/data/fast_recovery_area/content/control_files
mkdir -p /opt/app/oracle/admin/content/adump
mkdir -p /opt/app/oracle/admin/content/dpdump
mkdir -p /opt/app/oracle/admin/content/pfile
mkdir -p /opt/app/oracle/audit
mkdir -p /opt/app/oracle/cfgtoollogs/dbca/content
mkdir -p /opt/app/oracle/product/12.1.0/dbhome_1/dbs
umask ${OLD_UMASK}
PERL5LIB=$ORACLE_HOME/rdbms/admin:$PERL5LIB; export PERL5LIB
ORACLE_SID=content; export ORACLE_SID
PATH=$ORACLE_HOME/bin:$PATH; export PATH
echo You should Add this entry in the /etc/oratab: content:/opt/app/oracle/product/12.1.0/dbhome_1:Y
/opt/app/oracle/product/12.1.0/dbhome_1/bin/sqlplus /nolog @/opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates/scr/content.sql
