set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
host /opt/app/oracle/product/12.1.0/dbhome_1/bin/orapwd file=/opt/app/oracle/product/12.1.0/dbhome_1/dbs/orapwcontent force=y format=12
@/opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates/scr/CloneRmanRestore.sql
@/opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates/scr/cloneDBCreation.sql
@/opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates/scr/postScripts.sql
@/opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates/scr/lockAccount.sql
@/opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates/scr/postDBCreation.sql
