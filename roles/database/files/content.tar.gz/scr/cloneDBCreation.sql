SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates/scr/cloneDBCreation.log append
shutdown abort;
startup nomount pfile="/opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates/scr/init.ora";
Create controlfile reuse set database "content"
MAXINSTANCES 8
MAXLOGHISTORY 1
MAXLOGFILES 16
MAXLOGMEMBERS 3
MAXDATAFILES 100
Datafile 
'&&file0',
'&&file1',
'&&file2',
'&&file3'
LOGFILE GROUP 1 ('/mnt/data/basesdedatos/content/redo_logs/redo01.log') SIZE 100M,
GROUP 2 ('/mnt/data/basesdedatos/content/redo_logs/redo02.log') SIZE 100M,
GROUP 3 ('/mnt/data/basesdedatos/content/redo_logs/redo03.log') SIZE 100M RESETLOGS;
exec dbms_backup_restore.zerodbid(0);
shutdown immediate;
startup nomount pfile="/opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates/scr/initcontentTemp.ora";
Create controlfile reuse set database "content"
MAXINSTANCES 8
MAXLOGHISTORY 1
MAXLOGFILES 16
MAXLOGMEMBERS 3
MAXDATAFILES 100
Datafile 
'&&file0',
'&&file1',
'&&file2',
'&&file3'
LOGFILE GROUP 1 ('/mnt/data/basesdedatos/content/redo_logs/redo01.log') SIZE 100M,
GROUP 2 ('/mnt/data/basesdedatos/content/redo_logs/redo02.log') SIZE 100M,
GROUP 3 ('/mnt/data/basesdedatos/content/redo_logs/redo03.log') SIZE 100M RESETLOGS;
alter system enable restricted session;
alter database "content" open resetlogs;
exec dbms_service.delete_service('seeddata');
exec dbms_service.delete_service('seeddataXDB');
alter database rename global_name to "content";
ALTER TABLESPACE TEMP ADD TEMPFILE '/mnt/data/basesdedatos/content/system_dbfs/temp01.dbf' SIZE 61440K REUSE AUTOEXTEND ON NEXT 640K MAXSIZE UNLIMITED;
select tablespace_name from dba_tablespaces where tablespace_name='USERS';
alter user sys account unlock identified by "&&sysPassword";
alter user system account unlock identified by "&&systemPassword";
select sid, program, serial#, username from v$session;
alter database character set INTERNAL_CONVERT WE8MSWIN1252;
alter database national character set INTERNAL_CONVERT AL16UTF16;
alter system disable restricted session;
