connect target sys/&1;
 
CATALOG START WITH   '/opt/app/oracle/product/12.1.0/dbhome_1/assistants/dbca/templates//Seed_Database.dfb'  NOPROMPT  ;

RUN {  

set newname for datafile 3 to  '/mnt/data/basesdedatos/content/system_dbfs/sysaux01.dbf' ; 

set newname for datafile 1 to  '/mnt/data/basesdedatos/content/system_dbfs/system01.dbf' ; 

set newname for datafile 6 to  '/mnt/data/basesdedatos/content/system_dbfs/users01.dbf' ; 

set newname for datafile 4 to  '/mnt/data/basesdedatos/content/system_dbfs/undotbs01.dbf' ; 

restore datafile 3; 

restore datafile 1; 

restore datafile 6; 

restore datafile 4; }
